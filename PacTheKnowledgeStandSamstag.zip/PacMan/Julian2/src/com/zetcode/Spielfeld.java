package com.zetcode;

public class Spielfeld {

	public void kaffeeWirdKalt() {
		// TODO Auto-generated method stub
		
	}

	public void kaffeeIstFertig(int i) {
		// TODO Auto-generated method stub
		
	}

}
