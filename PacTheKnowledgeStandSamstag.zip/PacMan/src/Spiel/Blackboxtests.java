package Spiel;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Blackboxtests {

	@Before
	public void setUp() throws Exception {
		Board testBoard1=new Board();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		
	}

}
