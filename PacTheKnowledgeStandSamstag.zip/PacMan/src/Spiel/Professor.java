package Spiel;

import java.awt.Image;

import javax.swing.ImageIcon;

public class Professor {

	private int ghostSpeed;
	private Image ghost;
	
	
	
	
	
	/**
	 * @return the ghost
	 */
	public Image getGhost() {
		return ghost;
	}




	/**
	 * @param ghost the ghost to set
	 */
	public void setGhost(Image ghost) {
		this.ghost = ghost;
	}




	Professor(){
		this.loadImages();
	}

	
	
	
	private void loadImages() {
		ghost = new ImageIcon("images/ghost.png").getImage();
    }


	/**
	 * @return the ghostSpeed
	 */
	public int getGhostSpeed() {
		return ghostSpeed;
	}

	/**
	 * @param ghostSpeed the ghostSpeed to set
	 */
	public void setGhostSpeed(int ghostSpeed) {
		this.ghostSpeed = ghostSpeed;
	}
	
	
	
}
